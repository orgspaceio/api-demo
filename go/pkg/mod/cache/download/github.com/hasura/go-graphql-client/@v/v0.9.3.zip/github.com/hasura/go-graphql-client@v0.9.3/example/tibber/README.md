# GraphQL client demo with Tibber

## How to run

Go to [https://developer.tibber.com/explorer](https://developer.tibber.com/explorer) and get the demo token.

```sh
export TIBBER_DEMO_TOKEN=<token>
go run .
```
