// Package graphql provides a GraphQL client implementation.
//
// For more information, see package github.com/hasura/go-graphql-client
//
// For now, see README for more details.
package graphql
